#!C:\Users\user\Desktop\django-scheduler-develop\myvenv\Scripts\python.exe
# EASY-INSTALL-ENTRY-SCRIPT: 'icalendar==4.0.3','console_scripts','icalendar'
__requires__ = 'icalendar==4.0.3'
import re
import sys
from pkg_resources import load_entry_point

if __name__ == '__main__':
    sys.argv[0] = re.sub(r'(-script\.pyw?|\.exe)?$', '', sys.argv[0])
    sys.exit(
        load_entry_point('icalendar==4.0.3', 'console_scripts', 'icalendar')()
    )
